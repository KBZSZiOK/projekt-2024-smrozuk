<form method="post">
        <div id="lewo">
        <input type="submit" value= "filmy" name="filmy" class="submity"></input><br><br>
        <input type="submit" value= "filmy_rodzaj" name="filmy_rodzaj" class="submity"></input><br><br>
        <input type="submit" value= "rodzaj_filmu" name="rodzaj_filmu" class="submity"></input><br><br>
        <input type="submit" value= "seanse" name="seanse" class="submity"></input><br><br>
        <input type="submit" value= "klienci" name="klienci" class="submity"></input><br><br>
        <input type="submit" value= "bilety" name="bilety" class="submity"></input><br><br>
        <input type="submit" value= "sale" name="sale" class="submity"></input><br><br>
        <input type="submit" value= "sprzedawcy" name="sprzedawcy" class="submity"></input><br><br>
        </form>