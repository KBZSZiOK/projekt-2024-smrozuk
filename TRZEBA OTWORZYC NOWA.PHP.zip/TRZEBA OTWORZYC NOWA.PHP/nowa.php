<!DOCTYPE html>
<html lang="pl">
    <?php
    include('./baner.php');
    ?>
    <div id="srodek">
    <?php
    include('./srodek.php');
    ?>
        </div>

        <div id="prawo">
            <?php
                include('./polacz.php');

                include('./filmy.php');
                include('./filmy_rodzaj.php');
                include('./bilety.php');
                include('./rodzaj_filmu.php');
                include('./seanse.php');
                include('./klienci.php');
                include('./sale.php');
                include('./sprzedawcy.php');
            ?>
          </div>
    </div>
    <div id="stopka"><p id="tekst">Stronę wykonał Szymon Mrozewski</p></div>

    <script src="skrypt.js"></script>
</body>
</html>