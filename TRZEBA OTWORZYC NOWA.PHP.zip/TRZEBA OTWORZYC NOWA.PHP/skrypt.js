const tekst = document.querySelector("#tekst");
let position = 0;


function animate() {
  position += 5;
  tekst.style.left = position + 'px';

  if (position > window.innerWidth) {
    position = -50;
  }

  requestAnimationFrame(animate);
}

animate();