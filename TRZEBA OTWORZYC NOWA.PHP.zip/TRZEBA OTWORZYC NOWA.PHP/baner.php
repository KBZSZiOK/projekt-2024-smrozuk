<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Baza danych</title>
    <link rel="stylesheet" href="dd.css">
</head>
<body>
    <div id="baner">
    <img src="kino.webp" id="zdj">
        <h1>KINO</h1>

    </div>