<?php
       if(isset($_POST["sale"])){
        echo 
        "<table>
        <tr>
            <td>ID</td>
            <td>Ilosc_miejsc</td>
        </tr>";
        while($row = mysqli_fetch_assoc($sale)){
            echo "<tr>
            <td>".$row['ID']. "</td>
            <td>".$row['Ilosc_miejsc']."</td>
            </tr>";
        }
        echo "</table>";
        echo '
        <form method="POST">
            <div id="dif">
            Podaj ilosc miejsc<input type="text" class="DODAJ" name="iloscmiejsc">
            </div><br>
            <input type="hidden" name="przeslij6" value="przes"></input>
            <input type="submit" value="przeslij"  id="przeslij"></input>
        </form>
    ';
    }
    if(isset($_POST["przeslij6"])){
        if(empty($_POST["iloscmiejsc"])){
            echo "Wprowadź dane!";
        }
        else{
            $iloscmiejsc = $_POST["iloscmiejsc"];

            $wprowadz = "insert into sale(Ilosc_miejsc) values('$iloscmiejsc')";
            $run = mysqli_query($conn,$wprowadz);
            if($run){
                echo "Wprowadzono dane!";
            }
            else{
                echo "Nie wprowadzono danych";
            }
        }
    } 
?>