<?php
        if(isset($_POST["sprzedawcy"])){
            echo 
            "<table>
            <tr>
                <td>ID</td>
                <td>Imie</td>
                <td>Nazwisko</td>
            </tr>";
            while($row = mysqli_fetch_assoc($sprzedawcy)){
                echo "<tr>
                <td>".$row['ID']. "</td>
                <td>".$row['Imie']."</td>
                <td>".$row['Nazwisko']."</td>
                </tr>";
            }
            echo "</table>";
            echo '
            <form method="POST">
                <div id="dif">
                Podaj imię<input type="text" class="DODAJ" name="Imie">
                Podaj nazwisko<input type="text" class="DODAJ" name="Nazwisko">
                </div><br>
                <input type="hidden" name="przeslij7" value="przes"></input>
                <input type="submit" value="przeslij"  id="przeslij"></input>
            </form>
        ';     
        }
        if(isset($_POST["przeslij7"])){
            if(empty($_POST["Imie"]) || empty($_POST["Nazwisko"])){
                echo "Wprowadź dane!";
            }
            else{
                $Imie = $_POST["Imie"];
                $Nazwisko = $_POST["Nazwisko"];
    
                $wprowadz = "insert into sprzedawcy(Imie,Nazwisko) values('$Imie','$Nazwisko')";
                $run = mysqli_query($conn,$wprowadz);
                if($run){
                    echo "Wprowadzono dane!";
                }
                else{
                    echo "Nie wprowadzono danych";
                }
            }
        }
?>