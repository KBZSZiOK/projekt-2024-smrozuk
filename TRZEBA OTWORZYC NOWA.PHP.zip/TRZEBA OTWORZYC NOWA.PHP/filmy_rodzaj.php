<?php
        if(isset($_POST["filmy_rodzaj"])){
            echo 
            "<table>
            <tr>
                <td>ID</td>
                <td>Filmy_ID</td>
                <td>Rodzaj_ID</td>
            </tr>";
            while($row = mysqli_fetch_assoc($filmy_rodzaj)){
                echo "<tr>
                <td>".$row['ID']. "</td>
                <td>".$row['Filmy_ID']."</td>
                <td>".$row['Rodzaj_ID']."</td>
                </tr>";
            }
            echo "</table>";
            echo '
            <form method="POST">
                <div id="dif">
                Podaj ID filmu<input type="text" class="DODAJ" name="film">
                Podaj ID rodzaju<input type="text" class="DODAJ" name="rodzaj">
                </div><br>
                <input type="hidden" name="przeslij2" value="przes"></input>
                <input type="submit" value="przeslij"  id="przeslij"></input>
            </form>
        ';
    }
    if(isset($_POST["przeslij2"])){
        if(empty($_POST["film"]) || empty($_POST["rodzaj"])){
            echo "Wprowadź dane!";
        }
        else{
            $Film_ID = $_POST["film"];
            $Rodzaj_ID = $_POST["rodzaj"];

            $wprowadz = "insert into filmy_rodzaj(Filmy_ID,Rodzaj_ID) values('$Film_ID','$Rodzaj_ID')";
            $run = mysqli_query($conn,$wprowadz);
            if($run){
                echo "Wprowadzono dane!";
            }
            else{
                echo "Nie wprowadzono danych";
            }
        }
    }   
?>