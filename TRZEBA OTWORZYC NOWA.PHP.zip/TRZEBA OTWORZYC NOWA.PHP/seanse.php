<?php
        if(isset($_POST["seanse"])){
            echo 
            "<table>
            <tr>
                <td>ID</td>
                <td>Termin</td>
                <td>Sala_ID</td>
                <td>Film_ID</td>
                <td>Liczba_wolnych_miejsc</td>
            </tr>";
            while($row = mysqli_fetch_assoc($seanse)){
                echo "<tr>
                <td>".$row['ID']. "</td>
                <td>".$row['Termin']."</td>
                <td>".$row['Sala_ID']."</td>
                <td>".$row['Film_ID']."</td>
                <td>".$row['Liczba_wolnych_miejsc']."</td>
                </tr>";
            }
            echo "</table>";
            echo '
            <form method="POST">
                <div id="dif">
                Podaj termin<input type="text" class="DODAJ" name="Termin">
                Podaj ID sali<input type="text" class="DODAJ" name="Sala_ID">
                Podaj ID filmu<input type="text" class="DODAJ" name="Film_ID">
                Podaj liczbe wolnych miejsc<input type="text" class="DODAJ" name="Liczba_wolnych_miejsc">
                </div><br>
                <input type="hidden" name="przeslij4" value="przes"></input>
                <input type="submit" value="przeslij"  id="przeslij"></input>
            </form>
        ';
        }
        if(isset($_POST["przeslij4"])){
            if(empty($_POST["Termin"]) || empty($_POST["Sala_ID"]) || empty($_POST["Film_ID"]) || empty($_POST["Liczba_wolnych_miejsc"])){
                echo "Wprowadź dane!";
            }
            else{
                $Termin = $_POST["Termin"];
                $Sala_ID = $_POST["Sala_ID"];
                $Film_ID = $_POST["Film_ID"];
                $Liczba_wolnych_miejsc = $_POST["Liczba_wolnych_miejsc"];
    
                $wprowadz = "insert into seanse(Termin,Sala_ID,Film_ID,Liczba_wolnych_miejsc) values('$Termin','$Sala_ID','$Film_ID','$Liczba_wolnych_miejsc')";
                $run = mysqli_query($conn,$wprowadz);
                if($run){
                    echo "Wprowadzono dane!";
                }
                else{
                    echo "Nie wprowadzono danych";
                }
            }
        }  
?>