<?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "kino"; 
            $conn = new mysqli($servername, $username, $password, $database);
        
            if ($conn->connect_error) {
                die("Błąd połączenia: " . $conn->connect_error);
            }

                
            $filmy = mysqli_query($conn, "select * from filmy");
            $filmy_rodzaj = mysqli_query($conn, "select * from filmy_rodzaj");
            $bilety = mysqli_query($conn, "select * from bilety");
            $rodzaj_filmu = mysqli_query($conn, "select * from rodzaj_filmu");
            $seanse = mysqli_query($conn, "select * from seanse");
            $klienci = mysqli_query($conn, "select * from klienci");
            $sale = mysqli_query($conn, "select * from sale");
            $sprzedawcy = mysqli_query($conn, "select * from sprzedawcy");
    
?>