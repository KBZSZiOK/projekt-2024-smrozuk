<?php
        if(isset($_POST["rodzaj_filmu"])){
            echo 
            "<table>
            <tr>
                <td>ID</td>
                <td>Nazwa</td>
            </tr>";
            while($row = mysqli_fetch_assoc($rodzaj_filmu)){
                echo "<tr>
                <td>".$row['ID']. "</td>
                <td>".$row['Nazwa']."</td>
                </tr>";
            }
            echo "</table>";
            echo '
            <form method="POST">
                <div id="dif">
                Podaj nazwę rodzaju<input type="text" class="DODAJ" name="Nazwa">
                </div><br>
                <input type="hidden" name="przeslij8" value="przes"></input>
                <input type="submit" value="przeslij"  id="przeslij"></input>
            </form>
        ';
        }
        if(isset($_POST["przeslij8"])){
            if(empty($_POST["Nazwa"])){
                echo "Wprowadź dane!";
            }
            else{
                $Nazwa = $_POST["Nazwa"];

                $wprowadz = "insert into rodzaj_filmu(Nazwa) values('$Nazwa')";
                $run = mysqli_query($conn,$wprowadz);
                if($run){
                    echo "Wprowadzono dane!";
                }
                else{
                    echo "Nie wprowadzono danych";
                }
            }
        }  

?>