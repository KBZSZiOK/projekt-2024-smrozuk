<?php
        if(isset($_POST["bilety"])){
            echo 
            "<table>
            <tr>
                <td>ID</td>
                <td>Seans_ID</td>
                <td>Sprzedawca_ID</td>
                <td>Klient_ID</td>
                <td>Cena</td>
            </tr>";
            while($row = mysqli_fetch_assoc($bilety)){
                echo "<tr>
                <td>".$row['ID']."</td>
                <td>".$row['Seans_ID']."</td>
                <td>".$row['Sprzedawca_ID']."</td>
                <td>".$row['Klient_ID']."</td>
                <td>".$row['Cena']."</td>
                </tr>";
            }
            echo "</table>";
            echo '
            <form method="POST">
                <div id="dif">
                Podaj ID seansu<input type="text" class="DODAJ" name="Seans_ID">
                Podaj ID sprzedawcy<input type="text" class="DODAJ" name="Sprzedawca_ID">
                Podaj ID klienta<input type="text" class="DODAJ" name="Klient_ID">
                Podaj cenę<input type="text" class="DODAJ" name="Cena">
                </div><br>
                <input type="hidden" name="przeslij3" value="przes"></input>
                <input type="submit" value="przeslij"  id="przeslij"></input>
            </form>
        ';
    }
    if(isset($_POST["przeslij3"])){
        if(empty($_POST["Seans_ID"]) || empty($_POST["Sprzedawca_ID"]) || empty($_POST["Klient_ID"]) || empty($_POST["Cena"])){
            echo "Wprowadź dane!";
        }
        else{
            $Seans_ID = $_POST["Seans_ID"];
            $Sprzedawca_ID = $_POST["Sprzedawca_ID"];
            $Klient_ID = $_POST["Klient_ID"];
            $Cena = $_POST["Cena"];

            $wprowadz = "insert into bilety(Seans_ID,Sprzedawca_ID,Klient_ID,Cena) values('$Seans_ID','$Sprzedawca_ID','$Klient_ID','$Cena')";
            $run = mysqli_query($conn,$wprowadz);
            if($run){
                echo "Wprowadzono dane!";
            }
            else{
                echo "Nie wprowadzono danych";
            }
        }
    }  
?>