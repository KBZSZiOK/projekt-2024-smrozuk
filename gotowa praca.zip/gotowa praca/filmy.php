<?php
        if(isset($_POST["filmy"])){
            echo 
            "<table>
            <tr>
                <td>ID</td>
                <td>Tytul</td>
                <td>Rezyser</td>
                <td>Czas_trwania</td>
            </tr>";
            while($row = mysqli_fetch_assoc($filmy)){
                echo "<tr>
                <td>".$row['ID']. "</td>
                <td>".$row['Tytul']. "</td>
                <td>".$row['Rezyser']. "</td>
                <td>".$row['Czas_trwania']. "</td>
            </tr>";
            }
            echo "</table><br>";
            echo '
                <form method="POST">
                    <div id="dif">
                    Dodaj tytuł<input type="text" class="DODAJ" name="tytul">
                    Dodaj reżysera<input type="text" class="DODAJ" name="rezyser">
                    Czas trwania<input type="text" class="DODAJ" name="czas">
                    </div><br>
                    <input type="hidden" name="przeslij" value="przes"></input>
                    <input type="submit" value="przeslij"  id="przeslij"></input>
                </form>
            ';
      }
      if(isset($_POST["przeslij"])){
            if(empty($_POST["tytul"]) || empty($_POST["rezyser"]) || empty($_POST["czas"])){
                echo "Wprowadź dane!";
            }
            else{
                $tytul = $_POST["tytul"];
                $rezyser = $_POST["rezyser"];
                $czas = $_POST["czas"];

                $wprowadz = "insert into filmy(Tytul,Rezyser,Czas_trwania) values('$tytul','$rezyser','$czas')";
                $run = mysqli_query($conn,$wprowadz);
                if($run){
                    echo "Wprowadzono dane!";
                }
                else{
                    echo "Nie wprowadzono danych";
                }
            }
        }   
?>