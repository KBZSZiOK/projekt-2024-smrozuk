<?php
        if(isset($_POST["klienci"])){
            echo 
            "<table>
            <tr>
                <td>ID</td>
                <td>Imie</td>
                <td>Nazwisko</td>
                <td>Mail</td>
            </tr>";
            while($row = mysqli_fetch_assoc($klienci)){
                echo "<tr>
                <td>".$row['ID']. "</td>
                <td>".$row['Imie']."</td>
                <td>".$row['Nazwisko']."</td>
                <td>".$row['Mail']."</td>
                </tr>";
            }
            echo "</table>";
            echo '
            <form method="POST">
                <div id="dif">
                Podaj imię<input type="text" class="DODAJ" name="Imie">
                Podaj nazwisko<input type="text" class="DODAJ" name="Nazwisko">
                Podaj mail<input type="text" class="DODAJ" name="Mail">
                </div><br>
                <input type="hidden" name="przeslij5" value="przes"></input>
                <input type="submit" value="przeslij"  id="przeslij"></input>
            </form>
        ';
        }
        if(isset($_POST["przeslij5"])){
            if(empty($_POST["Imie"]) || empty($_POST["Nazwisko"]) || empty($_POST["Mail"])){
                echo "Wprowadź dane!";
            }
            else{
                $Imie = $_POST["Imie"];
                $Nazwisko = $_POST["Nazwisko"];
                $Mail = $_POST["Mail"];
    
                $wprowadz = "insert into klienci(Imie,Nazwisko,Mail) values('$Imie','$Nazwisko','$Mail')";
                $run = mysqli_query($conn,$wprowadz);
                if($run){
                    echo "Wprowadzono dane!";
                }
                else{
                    echo "Nie wprowadzono danych";
                }
            }
        }  
?>